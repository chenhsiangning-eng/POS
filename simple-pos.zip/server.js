const express = require('express');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

let orders = [];

app.post('/checkout', async (req, res) => {
  const { amount, token, cartItems, paymentMethod } = req.body;
  try {
    if(paymentMethod === 'card'){
      const charge = await stripe.charges.create({
        amount: amount * 100,
        currency: 'twd',
        source: token.id,
        description: 'POS 訂單付款'
      });
      orders.push({
        id: orders.length + 1,
        items: cartItems,
        amount,
        payment: '刷卡',
        date: new Date()
      });
      res.json({ success: true, charge });
    } else if(paymentMethod === 'cash'){
      orders.push({
        id: orders.length + 1,
        items: cartItems,
        amount,
        payment: '現金',
        date: new Date()
      });
      res.json({ success: true });
    }
  } catch (error) {
    res.json({ success: false, error: error.message });
  }
});

app.get('/orders', (req, res) => res.json(orders));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));